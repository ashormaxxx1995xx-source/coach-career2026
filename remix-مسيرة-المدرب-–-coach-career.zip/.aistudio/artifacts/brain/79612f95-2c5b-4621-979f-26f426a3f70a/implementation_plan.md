# مسيرة المدرب – COACH CAREER: Architectural & Implementation Plan

A comprehensive, realistic, and production-grade football management simulation game where the user ascends from managing a modest English lower-tier club to dominating European elite football. Built mobile-first with PWA offline persistence, Arabic (RTL) & English localization, dual-currency economy, tactical engine, individual player development, and a 1–100 coach progression track.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following decisions shape the gameplay loop and visual identity:

- **Starting Tier & Club**: English Tier 5 (National League / Conference) with authentic lower-tier clubs (e.g., York City, Oldham Athletic, Wrexham AFC, Chesterfield, Southend) plus an option to pick any English league or create a custom club.
- **Match Simulation Pacing**: 5s, 10s, or 15s selectable simulation speeds featuring live match event tickers (danger attacks, counter-attacks, shots on target, VAR, bookings), commentary cards, plus an instant "Fast-Forward / Skip to Result" toggle.
- **Stadium Audio & SFX**: Ambient crowd hum, referee whistle, goal roar, and celebratory fanfare, with a persistent 1-tap quick audio mute toggle on the top navigation bar.
- **Dual-Currency Separation**:
  - **Dollar ($)**: Club budget used for senior transfers, weekly payroll, stadium upgrades, medical, and scouting staff.
  - **Koro (KORO)**: Youth & scout tokens earned through level milestones, academy achievements, and wonderkid scouting. Strict zero-conversion rule between $ and KORO.
- **PES 2012 Transfer Cutscene**: Dynamic cinematic overlay showing player card, previous crest, animated transfer arrow, new club crest, contract length, signing fee, and official "Deal Completed" seal.
- **Coach Level 1 to 100 Track**: Visual scrolling milestone roadmap with level requirements, progressive XP/missions, and non-repeatable claimable rewards (cash, KORO tokens, youth scouting tickets, boost contracts).
- **PWA & Offline Installation**: Web App Manifest, Service Worker caching, and in-app install prompt for seamless Android home-screen launch and APK packaging.

---

## 1. Overview & Core Concept

- **What It Does**: Simulates the authentic day-to-day and matchday experience of a football manager. Players select tactics, manage contracts, scout wonderkids, negotiate transfers, develop academy players individually, upgrade club infrastructure, and guide their team through promotion/relegation and European cups.
- **Target Audience**: Mobile football fans and simulation enthusiasts who want deep strategic management without waiting for slow server turnarounds.
- **Key Value**: Fast, engaging, responsive gameplay that runs 100% locally with zero latency, full offline persistence (`localStorage`), rich Arabic RTL and English interfaces, and rewarding RPG progression.

---

## 2. User Experience & Visual Design

### Key User Flows

```
[ Intro Trailer & 3D Floating Start Button ]
                   │
                   ▼
[ Manager Setup & Club Selection (Lower Tiers) ]
                   │
                   ▼
┌─────────────────────────────────────────────────────────┐
│              MAIN DASHBOARD (Card Grid)                 │
│  Top Bar: $ Balance · KORO · Level (1-100) · Audio Mute │
├─────────────┬─────────────┬─────────────┬───────────────┤
│ Squad / XI  │ Tactics     │ Match Day   │ Transfer Mkt  │
├─────────────┼─────────────┼─────────────┼───────────────┤
│ Training    │ Youth Acad. │ Facilities  │ Finances      │
├─────────────┼─────────────┼─────────────┼───────────────┤
│ League Tbl  │ Levels/Prog │ Career Stats│ Settings/PWA  │
└─────────────┴─────────────┴─────────────┴───────────────┘
                   │
                   ├─► Match Simulation Modal (5s/10s/15s + Ticker + Stats)
                   ├─► PES 2012 Transfer Celebration Screen
                   └─► End-of-Season Rollover (Promotions / Relegations / Awards)
```

### Visual Identity & Theme
- **Color Palette & Atmospheric Dark Mode**:
  - Background Canvas: Deep stadium nocturnal slate (`#0B0F17` / `#111827`)
  - Accent / Primary Action: Electric pitch emerald (`#10B981` / `#059669`) and stadium gold (`#F59E0B`)
  - Secondary Currency (KORO): Luminous violet-cyan gradient accent (`#8B5CF6`)
  - Hairline Borders: Muted slate (`rgba(255, 255, 255, 0.08)`)
- **Typography & Localization**:
  - Arabic: Modern, high-legibility geometric Naskh (`Cairo` / `Tajawal` font family) with full native `dir="rtl"` layout flip.
  - English / Numerals: Clean athletic neo-grotesque (`Plus Jakarta Sans` / `Outfit`) with `font-mono tabular-nums` for all financial figures, minutes, and player stats.
- **Cinematic Start Screen**:
  - Video/Canvas dynamic motion backdrop featuring stadium floodlights, evening mist, and cinematic football action.
  - Floating 3D extruded start button with rhythmic floating hover physics, rim lighting, and tactile press response.
- **Main Navigation**: Modern bento card grid with rich illustrated iconography, instant progress indicators, and badge-free typography.

---

## 3. Key Product Decisions & Trade-Offs

- **Client-Side Simulation vs Server Engine**:
  - *Chosen Approach*: Fully client-authoritative deterministic match simulation written in TypeScript.
  - *Why*: Instant responses, seamless offline play, zero latency, zero cloud costs, and full compatibility with PWA installation and Android APK wrappers.
- **Persistence Strategy**:
  - *Chosen Approach*: Robust JSON schema in `localStorage` with automated migration, auto-save after every action, and manual export/import JSON backup.
  - *Why*: Immune to network drops; progress is never lost even if the browser process is killed.
- **PES 2012 Transfer Sequence**:
  - *Chosen Approach*: CSS 3D transformed card presentation with sound effect, dynamic arrows, and confetti particle bursts.
  - *Why*: Evokes beloved classic console nostalgia while remaining lightweight and performant on mobile web.
- **Player Database & Imagery**:
  - *Chosen Approach*: Curated dataset of real football clubs across England and Europe with licensed/creative-commons images and stylized high-fidelity player silhouette badges and attributes.

---

## 4. Technical Architecture & Data Strategy

```
┌──────────────────────────────────────────────────────────────────┐
│                         App State Store                          │
│  - ManagerProfile (Name, Nationality, Reputation, Season, XP)    │
│  - Club (ID, Name, Crest, Tier, Stadium, Facilities, Finances)   │
│  - Squad (22+ Players: Attributes, Contracts, Morale, Training)  │
│  - LeagueTable (Points, GD, Form, Fixtures)                      │
│  - TransferMarket (Listed Players, Bids, Expiring Contracts)     │
│  - YouthAcademy (Scouted Wonderkids, Discovery Timer)            │
│  - LevelRoadmap (Levels 1-100, Quests, Claimed Rewards)          │
│  - Settings (Lang: AR/EN, Sound: On/Off, SimSpeed: 5/10/15s)     │
└─────────────────────────────────┬────────────────────────────────┘
                                  │
         ┌────────────────────────┼────────────────────────┐
         ▼                        ▼                        ▼
┌──────────────────┐    ┌──────────────────┐     ┌──────────────────┐
│  Tactics Engine  │    │  Economy Engine  │     │ Progression Sys  │
│  - Formation Map │    │  - Dollar Pool   │     │  - Levels 1-100  │
│  - Match Ticker  │    │  - KORO Pool     │     │  - Quest Matrix  │
│  - Event Gen     │    │  - Wage Deduct   │     │  - Reward Vault  │
│  - Post-Match    │    │  - Facility ROI  │     │  - Career Record │
└──────────────────┘    └──────────────────┘     └──────────────────┘
```

### Core Subsystems to Build

1. **Manager & Club Initiation**: Selection screen for manager name, nationality, and English tier starting club with realistic ratings (55–65 OVR for tier 5, expanding upwards).
2. **Tactics & Formation Board**: Drag-and-drop or tap-to-swap player positions, tactical mentalities (Attacking, Balanced, Defensive, Counter-Attack, High Press), set-piece & captain assignments.
3. **Simulation Engine (`MatchEngine.ts`)**: Probabilistic event engine generating time-stamped chances, cards, substitutions, dynamic possession rates, player ratings (1.0 to 10.0), and MOTM.
4. **Individual Player Development**: Targeted training per skill (Speed, Finishing, Passing, Defending, Physical, Dribbling, Stamina) with age curve, potential cap, facility level multiplier, and fatigue wear.
5. **Transfer Market & PES 2012 Deal Cutscene**: Search, filter by position/budget, bid negotiations, contract wage demands, agent counter-offers, and animated signing ceremony.
6. **Youth Academy & KORO Economy**: Scout talent tiers using KORO tokens, reveal hidden potential, promote prospects to senior squad.
7. **Facility Upgrades**: 10 distinct upgradable facilities (Stadium, Stands, Floodlights, Dressing Rooms, Training Ground, Gym, Medical Clinic, Scouting Hub, Youth Academy, Club Store) each offering tangible gameplay perks.
8. **Level 1 to 100 Quest Roadmap**: Comprehensive milestone track with 100 tiered challenges and rewarding gift unlocks (one-time claim verification).
9. **Season Rollover & European Competitions**: Promotion/relegation between divisions, FA Cup / League Cup draws, qualification into Champions League / Europa League, and annual financial prizes.
10. **PWA & Offline Packaging**: Service Worker, Web App Manifest, icon assets, install banner, audio synthesizer / sound player, and complete Arabic RTL / English toggle.

---

## 5. Phased Execution Steps

1. **Phase 1: Project Setup & Sound/Asset Foundation**
   - Configure Tailwind RTL support and Cairo/Outfit typography.
   - Setup Web Audio synthesizer for crowd hum, whistle, clicks, and goal effects.
   - Configure PWA manifest and service worker.
2. **Phase 2: Cinematic Intro & Manager Setup**
   - Build the cinematic video/visual intro screen with 3D glowing floating start button.
   - Create Manager Creation & Starting Club Picker modal.
3. **Phase 3: Core Dashboard & Squad/Tactics Engine**
   - Build the top stats bar ($ Balance, KORO, Level 1-100, Club crest, Audio toggle, Language switcher).
   - Build the visual Bento grid dashboard.
   - Implement Squad View, Player Profile cards, and Formation Pitch Board (4-3-3, 4-4-2, 4-2-3-1, 3-5-2, 4-1-4-1).
4. **Phase 4: Matchday Simulation & Event Ticker**
   - Implement the 5s/10s/15s match simulation with live play-by-play ticker commentary.
   - Display post-match scoreboard with player ratings, goalscorers, MOTM, and league points update.
5. **Phase 5: Transfer Market & PES 2012 Cutscene**
   - Build transfer list, search filters, and negotiation dialogs (fee, salary, length).
   - Implement the PES 2012 animated signing celebration overlay.
6. **Phase 6: Training, Youth Academy & Club Facilities**
   - Individual skill training system with progress bars.
   - KORO-powered Youth Academy scouting and promotion.
   - 10 upgradable club facilities with progressive gameplay perks.
7. **Phase 7: Levels 1-100 Roadmap, Multi-Season & Verification**
   - Build the 1–100 level visual progress track with quest validators and reward claiming.
   - Season rollover engine (promotions, relegations, European spots, new calendar).
   - Comprehensive compilation, responsiveness, and state persistence test.
