# COACH CAREER – Complete Football Manager Career Simulator

A deep, realistic, and fully functional football management career simulator built with a professional sports analytics interface in dark navy and graphite, supporting full bilingual Arabic (RTL) and English (LTR) experiences, mobile touch ergonomics, and an interconnected managerial simulation engine.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The clarifying questions were skipped, so we adopt the recommended production configuration:
> - **Pyramid & Competitions**: Full 5-tier English League system (Premier League, Championship, League One, League Two, National League) + Domestic National Cup & Challenge Trophy + European Champions Cup & Europa Cup for continental glory.
> - **Match Experience**: High-fidelity dual simulation: an interactive match day with live 2D pitch radar, minute-by-minute tactical commentary, in-match substitutions, and tactical shouts, combined with a quick-sim toggle for rapid progression.
> - **Career Freedom**: Choice of any starting club from Tier 1 to Tier 5, with realistic tier-graded expectations, budgets, and board confidence.
> - **Complete Save Portability**: Automatic persistent `localStorage` synchronization with one-click JSON Career File Export & Import so players never lose progress across devices or browser sessions.

---

## 1. Overview & Core Concept

**COACH CAREER** puts the player in the shoes of a modern football manager with total tactical, squad, financial, and developmental control:

- **Managerial Progression**: Build reputation (1–100) and manager level (1–100) through match victories, tactical triumphs, and board objectives. Earn job offers from bigger clubs or face the sack if board confidence collapses below critical levels.
- **Deep Club Management**: Manage squad fitness, morale, contract renewals, wage caps, buy/sell transfers with realistic bidding and counter-offers, hire coaching/medical/scouting staff, and promote wonderkids from the Youth Academy.
- **Dynamic Match Engine**: A 90-minute simulation with live 2D pitch radar visualizing ball movement and attacking waves, dynamic possession calculations, fouls, yellow/red cards, injuries, tactical substitutions, and post-match player ratings (1.0–10.0) with Man of the Match honors.
- **Financial Balance Sheet**: Manage transfer budgets, weekly wage bills, matchday gate receipts (scaling with stadium tier & capacity), seasonal sponsorships, competition prize money, and operational staff overheads.
- **Facility Evolution**: Upgrade 6 key club infrastructure pillars: Stadium Capacity, Training Grounds, Youth Academy, Medical Center, Fitness Complex, and Global Scouting Network, each providing tangible in-engine gameplay boosts.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Manager Creation & Club Appointment**: Select nationality, customize manager avatar, select starting club from 5 tiers (or start at the bottom for a Road to Glory), review initial board expectations, squad depth, and initial transfer/wage budgets.
2. **The Command Center (Dashboard)**:
   - High-impact header: Manager reputation badge, level XP progress bar, current date, season, club badge, stadium name, balance, and next opponent preview.
   - Quick Action bar: "Play Next Fixture" (high-visibility anchor button), "Manage Tactics", "Squad", "Transfers", "Finances", "Facilities", "Competitions", "Staff & Office".
   - Central overview: Next fixture breakdown, League table snapshot, recent form run, squad morale alerts, incoming transfer offers, and board confidence meter.
3. **Tactical Laboratory**:
   - Interactive tactical pitch with drag-and-drop or tap-to-swap starting XI positions and substitutes bench.
   - Formations: 4-3-3, 4-2-3-1, 4-4-2, 3-5-2, 5-3-2, 4-1-4-1, 3-4-3.
   - Mentality & Tactical Instructions: Attacking / Balanced / Defensive / Counter-Attack / High Press; Passing Style (Direct / Short / Mixed); Defensive Line (Deep / Medium / High); Pressing Intensity (Light / Balanced / Relentless).
   - Set-piece assignments: Team Captain and Penalty Taker selectors.
4. **Interactive Match Day**:
   - Pre-match team sheets and tactical briefing.
   - Live Match Arena: Animated 2D pitch radar tracking ball location and possession momentum, live Arabic/English commentary ticker, real-time scoreboard with goal scorers and card indicators.
   - In-game tactical interventions: tactical shouts (Push Forward, Tighten Defense, Calm Down), live substitutions (up to 5 subs), and injury management.
   - Post-match breakdown: Match ratings (1–10), MOTM, possession %, shots/target, attendance, gate revenue credited directly to club bank balance, and manager XP awarded.
5. **Transfers & Contract Negotiations**:
   - Comprehensive transfer market filterable by position, rating, price, and nationality.
   - Realistic negotiation modal: propose transfer fees, weekly wage, contract length, and release clauses. AI clubs and players evaluate offers based on club reputation and financial incentives.
   - Contract renewal system for existing squad members nearing expiry with wage demands.
6. **Competitions & Tournaments**:
   - League standings with full GD, GF, GA, points, form badges (W/D/L), promotion/relegation zones.
   - Domestic Cups (National Cup knockout tree) and European Cups for qualified clubs.
   - Player stat leaderboards: Golden Boot (top scorers), Playmaker Award (top assists), and Golden Glove (clean sheets).
7. **Club Office & Staff**:
   - Hire and upgrade Head Coach (boosts training progression), Head Scout (unlocks hidden potentials and scouting reports), and Chief Physio (speeds up injury recovery and reduces fatigue).
   - Job offers hub: clubs with vacancies reach out based on manager reputation and accomplishments.
8. **Save & Settings Center**:
   - Manual Save, Auto-Save indicator, Export Career to downloadable `.json` file, Import Career file with verification, Sound FX toggle, Language switch (Arabic / English), and Theme settings.

### Visual Identity & Theme Tokens

- **Aesthetic Direction**: Elite Sports Management & Performance Analytics (sleek dark graphite `#090e17`, midnight navy `#0f172a`, stadium emerald `#10b981` accents, pitch gold `#f59e0b`, and crisp white typography).
- **Typography**: Dual bilingual typography pairings:
  - Arabic: **Cairo** (Display & Body, bold weights 700/800 for sports headlines, 500/600 for UI labels).
  - English: **Plus Jakarta Sans** for interfaces and navigation, paired with **JetBrains Mono** (`tabular-nums`) for match scores, financial ledgers, and player OVR ratings.
- **Zero-Pill Discipline & Anti-Slop**:
  - No decorative purple gradients, no fake floating badges, no meaningless status dots.
  - Clean unboxed metadata separated by subtle typographical dividers (`·`).
  - Professional football statistics cards with crisp hairline borders (`border-slate-800`).
- **Touch Ergonomics & Mobile Layout**:
  - 44px+ touch targets on all interactive controls.
  - Fixed mobile navigation dock with thumb-friendly tabs (Dashboard, Squad, Tactics, Market, Office).
  - Clean desktop layout expanding to full multi-column analytical panels on wider screens.

---

## 3. Key Product Decisions & Trade-Offs

| Decision | Chosen Approach | Rationale | Alternatives Considered |
| :--- | :--- | :--- | :--- |
| **Match Engine** | Hybrid Simulation: Live 2D pitch radar + text commentary ticker + Instant-Sim mode | Gives players who love deep tactical immersion the excitement of real-time match events and shouts, while allowing fast players to instant-sim league games. | Pure text ticker (too dry) or heavy 3D engine (too slow, unstable on mobile). |
| **Competition Structure** | 5 English Tiers (Premier down to National League) + Domestic Cups + Continental Cups | Offers long-term multi-season replayability, promotion dreams, relegation battles, and European glory. | Single tier only (lacks career depth) or 20 countries (overwhelming data footprint). |
| **Staff & Facilities** | Modular upgrade trees with direct mathematical impact on player training, injury rates, ticket revenue, and scouting precision | Makes every dollar earned through matches and sponsorships feel earned and strategically invested. | Cosmetic upgrades with no gameplay impact. |
| **Save & Persistence** | Dual-layer: Auto-persisted `localStorage` + JSON Import/Export file system | Guarantees zero progress loss on mobile reloads or APK wraps, and allows cross-device backup. | Cloud-only login (requires external server) or memory-only (loses data on refresh). |

---

## 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                             COACH CAREER APPLICATION                        │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
     ┌─────────────────────────────────┼─────────────────────────────────┐
     ▼                                 ▼                                 ▼
┌──────────────┐              ┌─────────────────┐              ┌──────────────────┐
│ Audio Engine │              │ Storage Service │              │ Localization     │
│ (Web Audio)  │              │ (Local + JSON)  │              │ (Arabic & English│
└──────────────┘              └────────┬────────┘              └──────────────────┘
                                       │
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         CENTRAL GAME STATE STORE                            │
│  - ManagerProfile (XP, Level 1-100, Reputation, Confidence, History)        │
│  - MyClub (Tier 1-5, Facilities, Budget, Wage Bill, Stadium, Staff)         │
│  - Squad & Tactics (Starting XI, Subs, Formations, Mentalities, Roles)       │
│  - Competitions (5 League Tables, Domestic Cup Brackets, European Cups)     │
│  - TransferMarket (Players, Valuations, Active Bids, Contract Demands)      │
│  - FinancialLedger (Matchday, Wages, Transfers, Sponsorship, Reports)       │
│  - StaffRoster (Head Coach, Chief Scout, Head Physio)                       │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
     ┌───────────────────┬─────────────┴───────┬───────────────────┐
     ▼                   ▼                     ▼                   ▼
┌──────────────┐  ┌──────────────┐     ┌──────────────┐    ┌──────────────┐
│  Dashboard   │  │   Tactics    │     │ Match Engine │    │  Transfers & │
│  & Fixtures  │  │ & Squad Lab  │     │ 2D Radar Sim │    │  Contracts   │
└──────────────┘  └──────────────┘     └──────────────┘    └──────────────┘
     ▲                   ▲                     ▲                   ▲
     │                   │                     │                   │
┌────┴─────────┐  ┌──────┴───────┐     ┌───────┴──────┐    ┌───────┴──────┐
│  Finances &  │  │ Facilities & │     │ Competitions │    │ Career & Job │
│  Balance     │  │ Staff Center │     │ & Tables     │    │ Market Hub   │
└──────────────┘  └──────────────┘     └──────────────┘    └──────────────┘
```

### Key Data Entities

- **Club**: Includes `id`, `name`, `arName`, `tier` (1 to 5), `budgetDollars`, `wageBudgetWeekly`, `stadiumCapacity`, `ticketPrice`, `reputation`, `staff` (Coach, Scout, Physio levels), and `facilities` (Levels 1–5).
- **Player**: Attributes (Pace, Shooting, Passing, Dribbling, Defending, Physical, Stamina), OVR (1–99), Potential (1–99), Age, Position, Market Value, Wage, Contract Years, Fitness, Morale, and Season Stats.
- **Tactics**: Formation (4-3-3, 4-2-3-1, etc.), PlayStyle/Mentality, Passing Style, Defensive Line, Pressing Intensity, Starting XI IDs, Sub IDs, Captain ID, Penalty Taker ID.
- **MatchResult & Engine**: Pre-match probability calculation factoring tactics synergy, individual matchup ratings, home advantage, and morale. 90-minute event loop generating dynamic chances, goals, assists, saves, fouls, yellow/red cards, injuries, and player ratings (1–10).
- **Finances**: Dynamic cash flow tracking weekly wage expenses, gate receipts calculated from home match attendance (based on club tier, reputation, and stadium capacity), seasonal sponsorship payouts, and transfer amortizations.

---

## 5. Implementation Stages & Verification Plan

1. **Core Data & Types Expansion**:
   - Enrich `game.ts` with Staff management, detailed financial ledgers, cup competition structures, contract negotiation types, and job offer mechanics.
   - Expand `clubs.ts` with authentic clubs across all 5 tiers of English football with real color palettes and stadium data.
   - Expand `players.ts` with hundreds of realistic players, youth prodigies, and position-specific attributes.
2. **Advanced Match Engine & 2D Tactical Radar**:
   - Upgrade `MatchSimulationModal.tsx` and `matchEngine.ts` to include a live 2D pitch radar canvas showing ball movement and attacking plays, in-match substitution controls, tactical shouts, live ratings, and injury stops.
3. **Comprehensive Squad & Contract Management**:
   - Enhance `SquadView.tsx` and `PlayerDetailModal.tsx` with contract extension negotiations, training focus assignments, morale boosts, and transfer listing toggles.
4. **Realistic Transfer Market & Staff Center**:
   - Enhance `TransfersView.tsx` with structured bid negotiations (initial offer, counter-offer, wage negotiation, agent responses).
   - Create a dedicated Staff & Club Office modal for hiring and leveling up Coaches, Scouts, and Physios.
5. **Finances & Balance Sheet**:
   - Enhance `FinancesView.tsx` with weekly wage bill tracking, ticket sales forecasts, sponsorship deals, and financial health warnings.
6. **Career Progression, Job Offers & Sacking**:
   - Implement board expectations evaluation after matches.
   - Implement job offer invitations when manager reputation rises, and dismissal warnings if board confidence drops.
7. **Bilingual Arabic/English RTL/LTR & Save Portability**:
   - Full dictionary coverage in `translations.ts` for all managerial terms.
   - Test JSON export and import in `SettingsView.tsx` to verify zero data loss.
8. **Verification & Build**:
   - Run `compile_applet` to confirm clean compilation and zero TypeScript/lint errors.
