import React, { useEffect, useState, useRef } from 'react';
import { Club, MatchResult, Player, Tactics, MatchEvent } from '../types/game';
import { simulateMatch } from '../utils/matchEngine';
import { sound } from '../utils/audio';
import confetti from 'canvas-confetti';
import { Play, FastForward, Trophy, Star, Shield, Activity, X, Megaphone, Users, RefreshCw, AlertTriangle } from 'lucide-react';

interface MatchSimulationModalProps {
  isOpen: boolean;
  isArabic: boolean;
  myClub: Club;
  opponentClub: Club;
  mySquad: Player[];
  opponentSquad: Player[];
  tactics: Tactics;
  simDurationSec: 5 | 10 | 15;
  onChangeSimDuration: (sec: 5 | 10 | 15) => void;
  onFinishMatch: (result: MatchResult) => void;
  onClose: () => void;
}

export const MatchSimulationModal: React.FC<MatchSimulationModalProps> = ({
  isOpen,
  isArabic,
  myClub,
  opponentClub,
  mySquad,
  opponentSquad,
  tactics,
  simDurationSec,
  onChangeSimDuration,
  onFinishMatch,
  onClose,
}) => {
  const [phase, setPhase] = useState<'ready' | 'simulating' | 'finished'>('ready');
  const [activeCommentary, setActiveCommentary] = useState<string>('');
  const [matchResult, setMatchResult] = useState<MatchResult | null>(null);
  const [currentMinute, setCurrentMinute] = useState<number>(0);
  const [liveHomeScore, setLiveHomeScore] = useState<number>(0);
  const [liveAwayScore, setLiveAwayScore] = useState<number>(0);
  const [liveEvents, setLiveEvents] = useState<MatchEvent[]>([]);
  
  // Tactical Shouts
  const [activeShout, setActiveShout] = useState<string | null>(null);
  const [shoutCooldown, setShoutCooldown] = useState(false);
  
  // In-Match Substitution state
  const [isSubModalOpen, setIsSubModalOpen] = useState(false);
  const [subsUsed, setSubsUsed] = useState(0);
  const [activePitchXI, setActivePitchXI] = useState<string[]>([]);
  const [selectedOffId, setSelectedOffId] = useState<string | null>(null);
  const [selectedOnId, setSelectedOnId] = useState<string | null>(null);

  // 2D Ball Position
  const [ballPos, setBallPos] = useState({ x: 50, y: 50 });

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isOpen) {
      setPhase('ready');
      setMatchResult(null);
      setCurrentMinute(0);
      setLiveHomeScore(0);
      setLiveAwayScore(0);
      setLiveEvents([]);
      setSubsUsed(0);
      setActivePitchXI(tactics.startingXI.length === 11 ? tactics.startingXI : mySquad.slice(0, 11).map(p => p.id));
      setSelectedOffId(null);
      setSelectedOnId(null);
      setIsSubModalOpen(false);
      setActiveShout(null);
      setBallPos({ x: 50, y: 50 });
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isOpen, tactics.startingXI, mySquad]);

  if (!isOpen) return null;

  const handleStartSim = () => {
    sound.playWhistle();
    setPhase('simulating');

    const result = simulateMatch(myClub, opponentClub, mySquad, opponentSquad, tactics, true);
    setMatchResult(result);

    const msTotal = simDurationSec * 1000;
    const intervalMs = msTotal / 90; // tick every match minute
    let minute = 0;
    let homeS = 0;
    let awayS = 0;

    setActiveCommentary(isArabic ? 'صافرة البداية تنطلق! بالتوفيق للفريق.' : 'Match is underway! Good luck.');

    timerRef.current = setInterval(() => {
      minute += 1;
      setCurrentMinute(minute);

      // Check if any match event happened at this minute
      const ev = result.events.find(e => e.minute === minute);
      if (ev) {
        setLiveEvents(prev => [ev, ...prev]);
        setActiveCommentary(isArabic ? ev.textAr : ev.textEn);
        if (ev.type === 'goal') {
          sound.playGoalCheer();
          if (ev.isHome) homeS++;
          else awayS++;
          setLiveHomeScore(homeS);
          setLiveAwayScore(awayS);
        } else if (ev.type === 'yellow' || ev.type === 'red') {
          sound.playWhistle();
        }
      }

      // Animate ball position on 2D pitch based on attack/defense flow
      const attackingSwing = (Math.sin(minute * 0.4) * 35) + 50;
      const lateralSwing = (Math.cos(minute * 0.6) * 30) + 50;
      setBallPos({
        x: Math.max(10, Math.min(90, Math.round(attackingSwing))),
        y: Math.max(15, Math.min(85, Math.round(lateralSwing))),
      });

      if (minute >= 90) {
        if (timerRef.current) clearInterval(timerRef.current);
        finalizeResult(result);
      }
    }, intervalMs);
  };

  const handleInstantSkip = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (matchResult) {
      setCurrentMinute(90);
      setLiveHomeScore(matchResult.homeStats.score);
      setLiveAwayScore(matchResult.awayStats.score);
      setLiveEvents(matchResult.events);
      finalizeResult(matchResult);
    }
  };

  const finalizeResult = (result: MatchResult) => {
    setPhase('finished');
    sound.playWhistle();

    if (result.homeStats.score > result.awayStats.score) {
      sound.playGoalCheer();
      try {
        confetti({ particleCount: 70, spread: 60, origin: { y: 0.7 } });
      } catch (e) {
        console.error(e);
      }
    } else {
      sound.playRewardChime();
    }
  };

  const handleTacticalShout = (shoutKey: string, textAr: string, textEn: string) => {
    if (shoutCooldown) return;
    sound.playClick();
    setActiveShout(isArabic ? textAr : textEn);
    setShoutCooldown(true);
    setTimeout(() => {
      setActiveShout(null);
      setShoutCooldown(false);
    }, 4000);
  };

  const handleConfirmSub = () => {
    if (!selectedOffId || !selectedOnId) return;
    if (subsUsed >= 5) return;

    sound.playWhistle();
    setActivePitchXI(prev => prev.map(id => (id === selectedOffId ? selectedOnId : id)));
    setSubsUsed(prev => prev + 1);

    const offPlayer = mySquad.find(p => p.id === selectedOffId);
    const onPlayer = mySquad.find(p => p.id === selectedOnId);

    const subEvent: MatchEvent = {
      minute: currentMinute,
      type: 'sub',
      isHome: true,
      textAr: `🔄 تبديل تكتيكي: خروج ${offPlayer?.arName || ''} ودخول ${onPlayer?.arName || ''}`,
      textEn: `🔄 Tactical Sub: OFF ${offPlayer?.name || ''} | ON ${onPlayer?.name || ''}`,
    };

    setLiveEvents(prev => [subEvent, ...prev]);
    setActiveCommentary(isArabic ? subEvent.textAr : subEvent.textEn);

    setSelectedOffId(null);
    setSelectedOnId(null);
    setIsSubModalOpen(false);
  };

  const handleAcceptAndExit = () => {
    if (matchResult) {
      onFinishMatch(matchResult);
    }
  };

  const starters = activePitchXI.map(id => mySquad.find(p => p.id === id)).filter(Boolean) as Player[];
  const bench = mySquad.filter(p => !activePitchXI.includes(p.id));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-3xl bg-[#090e17] border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl text-slate-100 my-auto relative">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-4 mb-4">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base sm:text-lg font-black text-white">
              {isArabic ? 'غرفة محاكاة ومجريات المباراة' : 'Matchday Arena & Tactical Radar'}
            </h2>
          </div>

          {phase === 'ready' && (
            <div className="flex items-center gap-1.5 p-1 bg-slate-800/80 rounded-xl border border-slate-700/60">
              <span className="text-[10px] text-slate-400 px-1 font-semibold">
                {isArabic ? 'السرعة:' : 'Speed:'}
              </span>
              {([5, 10, 15] as const).map(sec => (
                <button
                  key={sec}
                  onClick={() => onChangeSimDuration(sec)}
                  className={`px-2 py-0.5 text-xs font-mono font-bold rounded-lg transition cursor-pointer min-h-[32px] ${
                    simDurationSec === sec
                      ? 'bg-emerald-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {sec}s
                </button>
              ))}
            </div>
          )}

          {phase !== 'simulating' && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white transition cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Scoreboard Card */}
        <div className="grid grid-cols-3 items-center py-4 px-4 rounded-2xl bg-slate-900/90 border border-slate-800 mb-4 text-center">
          {/* Home Club */}
          <div className="flex flex-col items-center">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-slate-800 border-2 border-emerald-500/50 flex items-center justify-center text-3xl shadow-lg">
              {myClub.crestIcon}
            </div>
            <span className="text-xs sm:text-sm font-bold text-white mt-2 truncate max-w-[120px]">
              {isArabic ? myClub.arName : myClub.name}
            </span>
            <span className="text-[10px] text-emerald-400 font-semibold">
              {isArabic ? 'صاحب الأرض' : 'Home'}
            </span>
          </div>

          {/* Center Score & Match Clock */}
          <div className="flex flex-col items-center">
            <div className="text-3xl sm:text-4xl font-black font-mono flex items-center gap-2">
              <span className="text-emerald-400">{phase === 'ready' ? 0 : liveHomeScore}</span>
              <span className="text-slate-600">:</span>
              <span className="text-rose-400">{phase === 'ready' ? 0 : liveAwayScore}</span>
            </div>
            <div className="mt-1.5 px-3 py-0.5 rounded-full bg-slate-800 border border-slate-700/80 font-mono text-xs font-bold text-amber-400">
              {phase === 'ready' ? "00' PRE" : phase === 'simulating' ? `${currentMinute}' LIVE` : "90' FT"}
            </div>
            <span className="text-[10px] text-slate-500 mt-1 font-mono truncate max-w-[140px]">
              {myClub.stadiumName}
            </span>
          </div>

          {/* Away Club */}
          <div className="flex flex-col items-center">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-slate-800 border-2 border-rose-500/30 flex items-center justify-center text-3xl shadow-lg">
              {opponentClub.crestIcon}
            </div>
            <span className="text-xs sm:text-sm font-bold text-white mt-2 truncate max-w-[120px]">
              {isArabic ? opponentClub.arName : opponentClub.name}
            </span>
            <span className="text-[10px] text-rose-400 font-semibold">
              {isArabic ? 'الضيف' : 'Away'}
            </span>
          </div>
        </div>

        {/* Phase 1: Pre-Match Briefing */}
        {phase === 'ready' && (
          <div className="text-center py-4 space-y-4">
            <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
              {isArabic
                ? 'تشكيلتك الأساسية تم نشرها في أرض الملعب، وتعليمات التكتيك واضحة. يمكنك توجيه صيحات تكتيكية وإجراء 5 تبديلات مباشرة أثناء سير اللعب!'
                : 'Your Starting XI is set. You can issue live tactical shouts and make up to 5 in-match substitutions during the match!'}
            </p>

            <button
              onClick={handleStartSim}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 hover:from-emerald-500 hover:to-teal-500 text-white text-sm sm:text-base font-black shadow-xl shadow-emerald-950/50 active:scale-98 transition flex items-center justify-center gap-2 cursor-pointer min-h-[50px]"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>{isArabic ? 'صافرة البداية وانطلاق المباراة ⚽' : 'Kick Off Match Now ⚽'}</span>
            </button>
          </div>
        )}

        {/* Phase 2: Live 2D Pitch Radar & Action */}
        {phase === 'simulating' && (
          <div className="space-y-4">
            {/* 2D Tactical Pitch Radar */}
            <div className="relative w-full h-36 sm:h-44 rounded-2xl bg-[#082015] border border-emerald-500/30 overflow-hidden shadow-inner flex items-center justify-center">
              {/* Pitch Grass Lines */}
              <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:24px_24px]" />
              
              {/* Center Circle & Halfway Line */}
              <div className="absolute left-1/2 top-0 bottom-0 w-[1px] bg-white/20 -translate-x-1/2" />
              <div className="absolute left-1/2 top-1/2 w-16 h-16 rounded-full border border-white/20 -translate-x-1/2 -translate-y-1/2" />

              {/* Penalty Boxes */}
              <div className="absolute left-0 top-1/4 bottom-1/4 w-12 border-r border-y border-white/20" />
              <div className="absolute right-0 top-1/4 bottom-1/4 w-12 border-l border-y border-white/20" />

              {/* Animated Ball */}
              <div
                className="absolute w-4 h-4 rounded-full bg-white shadow-lg shadow-white/80 border border-slate-900 transition-all duration-300 ease-out -translate-x-1/2 -translate-y-1/2 flex items-center justify-center text-[8px]"
                style={{ left: `${ballPos.x}%`, top: `${ballPos.y}%` }}
              >
                ⚽
              </div>

              {/* Direction Indicator */}
              <div className="absolute top-2 left-3 text-[10px] text-emerald-400 font-mono font-bold bg-slate-950/60 px-2 py-0.5 rounded">
                {isArabic ? `فريقك ◄ الهجوم` : `Your Team ◄ Attack`}
              </div>

              <div className="absolute bottom-2 right-3 text-[10px] text-slate-400 font-mono bg-slate-950/60 px-2 py-0.5 rounded">
                {currentMinute}' / 90'
              </div>
            </div>

            {/* Commentary Banner */}
            <div className="min-h-[50px] flex items-center justify-center px-4 py-2.5 rounded-2xl bg-slate-900/90 border border-slate-800 text-center">
              <span className="text-xs sm:text-sm font-bold text-emerald-300">
                {activeCommentary}
              </span>
            </div>

            {/* Tactical Shouts & Live Substitutions Controls */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="flex items-center gap-1 font-bold text-slate-300">
                  <Megaphone className="w-3.5 h-3.5 text-amber-400" />
                  <span>{isArabic ? 'صيحات وتوجيهات تكتيكية للملعب:' : 'Live Tactical Shouts:'}</span>
                </span>
                <button
                  onClick={() => setIsSubModalOpen(true)}
                  disabled={subsUsed >= 5}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition cursor-pointer min-h-[36px]"
                >
                  <Users className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{isArabic ? `إجراء تبديل (${subsUsed}/5)` : `Substitutions (${subsUsed}/5)`}</span>
                </button>
              </div>

              {/* Shout Buttons */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { key: 'attack', ar: '⚡ تقدموا للأمام!', en: '⚡ Push Forward!' },
                  { key: 'defend', ar: '🛡️ أحكموا الدفاع!', en: '🛡️ Park The Bus!' },
                  { key: 'press', ar: '🔥 ضغط عالي متواصل!', en: '🔥 High Press!' },
                  { key: 'calm', ar: '🧘 حافظوا على الكرة!', en: '🧘 Calm & Retain' },
                ].map(shout => (
                  <button
                    key={shout.key}
                    disabled={shoutCooldown}
                    onClick={() => handleTacticalShout(shout.key, shout.ar, shout.en)}
                    className="px-2.5 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-[11px] font-bold text-slate-200 transition cursor-pointer disabled:opacity-50 min-h-[38px] flex items-center justify-center"
                  >
                    {isArabic ? shout.ar : shout.en}
                  </button>
                ))}
              </div>

              {activeShout && (
                <div className="p-2 rounded-xl bg-amber-950/40 border border-amber-500/30 text-center text-xs font-bold text-amber-300 animate-in fade-in">
                  📢 {isArabic ? `المدرب يصيح: "${activeShout}"` : `Coach shouts: "${activeShout}"`}
                </div>
              )}
            </div>

            {/* Fast Forward Skip Button */}
            <div className="flex justify-end pt-1">
              <button
                onClick={handleInstantSkip}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold transition cursor-pointer min-h-[40px]"
              >
                <FastForward className="w-4 h-4 text-amber-400" />
                <span>{isArabic ? 'إنهاء فوري ومباشر' : 'Instant Result'}</span>
              </button>
            </div>
          </div>
        )}

        {/* Phase 3: Post-Match Full Analytical Report */}
        {phase === 'finished' && matchResult && (
          <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
            {/* Goals Scored List */}
            {matchResult.events.filter(e => e.type === 'goal').length > 0 && (
              <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1.5">
                <span className="text-xs font-bold text-slate-400 block">
                  {isArabic ? 'سجل الأهداف والمناسبات:' : 'Match Timeline & Goals:'}
                </span>
                {matchResult.events
                  .filter(e => e.type === 'goal')
                  .map((e, idx) => (
                    <div key={idx} className="text-xs text-slate-300 flex items-center justify-between">
                      <span className="font-semibold">{e.textAr || e.textEn}</span>
                      <span className="text-emerald-400 font-mono font-bold">{e.minute}'</span>
                    </div>
                  ))}
              </div>
            )}

            {/* Match Stats Grid */}
            <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono p-3 rounded-2xl bg-slate-950/70 border border-slate-800">
              <div className="text-emerald-400 font-bold">{matchResult.homeStats.possession}%</div>
              <div className="text-slate-400 font-sans">{isArabic ? 'الاستحواذ' : 'Possession'}</div>
              <div className="text-rose-400 font-bold">{matchResult.awayStats.possession}%</div>

              <div className="text-emerald-400 font-bold">{matchResult.homeStats.shots}</div>
              <div className="text-slate-400 font-sans">{isArabic ? 'التسديدات' : 'Shots'}</div>
              <div className="text-rose-400 font-bold">{matchResult.awayStats.shots}</div>

              <div className="text-emerald-400 font-bold">{matchResult.homeStats.shotsOnTarget}</div>
              <div className="text-slate-400 font-sans">{isArabic ? 'على المرمى' : 'On Target'}</div>
              <div className="text-rose-400 font-bold">{matchResult.awayStats.shotsOnTarget}</div>

              <div className="text-emerald-400 font-bold">{matchResult.homeStats.fouls}</div>
              <div className="text-slate-400 font-sans">{isArabic ? 'الأخطاء' : 'Fouls'}</div>
              <div className="text-rose-400 font-bold">{matchResult.awayStats.fouls}</div>
            </div>

            {/* Man of the Match (MOTM) & Gate Receipts */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-600/30 flex items-center gap-3">
                <Star className="w-5 h-5 text-amber-400 shrink-0 fill-current" />
                <div>
                  <span className="text-[10px] text-amber-400 font-semibold block">
                    {isArabic ? 'رجل المباراة (MOTM)' : 'Man of the Match'}
                  </span>
                  <span className="font-bold text-white">{matchResult.motmPlayerName}</span>
                  <span className="text-amber-300 font-mono ml-2 font-bold">({matchResult.motmRating} ★)</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-600/30 flex items-center gap-3">
                <Trophy className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <span className="text-[10px] text-emerald-400 font-semibold block">
                    {isArabic ? 'إيرادات تذاكر الملعب' : 'Matchday Gate Income'}
                  </span>
                  <span className="font-bold text-white font-mono">+${matchResult.gateIncome.toLocaleString()}</span>
                  <span className="text-slate-400 text-[10px] ml-1">({matchResult.attendance.toLocaleString()} {isArabic ? 'مشجع' : 'Fans'})</span>
                </div>
              </div>
            </div>

            {/* Player Ratings Table */}
            <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800">
              <span className="text-xs font-bold text-slate-300 block mb-2">
                {isArabic ? 'تقييمات لاعبي فريقك (من 10):' : 'Squad Match Performance Ratings:'}
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                {starters.map(player => {
                  const rating = matchResult.playerRatings[player.id] || 7.0;
                  return (
                    <div key={player.id} className="p-2 rounded-xl bg-slate-800/60 border border-slate-700/50 flex items-center justify-between">
                      <div className="truncate pr-2">
                        <span className="text-[10px] font-mono text-emerald-400 font-bold mr-1">[{player.position}]</span>
                        <span className="text-slate-200 truncate">{isArabic ? player.arName : player.name}</span>
                      </div>
                      <span className={`font-mono font-bold ${rating >= 7.5 ? 'text-emerald-400' : rating >= 6.5 ? 'text-amber-400' : 'text-slate-400'}`}>
                        {rating}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Return / Accept Button */}
            <button
              onClick={handleAcceptAndExit}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-sm font-black shadow-lg shadow-emerald-950/40 active:scale-98 transition cursor-pointer min-h-[48px]"
            >
              {isArabic ? 'العودة للمقر واعتماد النتيجة الرسمية' : 'Accept Result & Return to HQ'}
            </button>
          </div>
        )}

        {/* Live Substitution Modal Drawer */}
        {isSubModalOpen && (
          <div className="absolute inset-0 z-20 bg-slate-950/95 rounded-3xl p-4 sm:p-6 flex flex-col justify-between animate-in fade-in">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <RefreshCw className="w-4 h-4 text-cyan-400" />
                  <span>{isArabic ? 'إجراء تبديل تكتيكي مباشر' : 'Make In-Match Substitution'}</span>
                </h3>
                <button
                  onClick={() => setIsSubModalOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-3">
                {/* On-Pitch Players (Select to sub off) */}
                <div>
                  <span className="text-xs font-semibold text-rose-400 block mb-2">
                    {isArabic ? 'اختر اللاعب الخارج (من الملعب):' : 'Select Player to come OFF:'}
                  </span>
                  <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                    {starters.map(p => (
                      <button
                        key={p.id}
                        onClick={() => setSelectedOffId(p.id)}
                        className={`w-full text-left rtl:text-right px-2.5 py-1.5 rounded-xl text-xs flex items-center justify-between border cursor-pointer min-h-[38px] ${
                          selectedOffId === p.id
                            ? 'bg-rose-950/60 border-rose-500 text-white font-bold'
                            : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <span className="truncate">
                          [{p.position}] {isArabic ? p.arName : p.name}
                        </span>
                        <span className="font-mono text-[10px] text-slate-400">{p.fitness}% Fit</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Bench Players (Select to sub on) */}
                <div>
                  <span className="text-xs font-semibold text-emerald-400 block mb-2">
                    {isArabic ? 'اختر البديل الداخل (من الدكة):' : 'Select Player to come ON:'}
                  </span>
                  <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                    {bench.slice(0, 7).map(p => (
                      <button
                        key={p.id}
                        onClick={() => setSelectedOnId(p.id)}
                        className={`w-full text-left rtl:text-right px-2.5 py-1.5 rounded-xl text-xs flex items-center justify-between border cursor-pointer min-h-[38px] ${
                          selectedOnId === p.id
                            ? 'bg-emerald-950/60 border-emerald-500 text-white font-bold'
                            : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <span className="truncate">
                          [{p.position}] {isArabic ? p.arName : p.name}
                        </span>
                        <span className="font-mono text-[10px] text-emerald-400 font-bold">{p.ovr} OVR</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                onClick={() => setIsSubModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-bold transition cursor-pointer min-h-[40px]"
              >
                {isArabic ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={handleConfirmSub}
                disabled={!selectedOffId || !selectedOnId}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition cursor-pointer disabled:opacity-50 min-h-[40px]"
              >
                {isArabic ? 'تأكيد التبديل' : 'Confirm Sub'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
