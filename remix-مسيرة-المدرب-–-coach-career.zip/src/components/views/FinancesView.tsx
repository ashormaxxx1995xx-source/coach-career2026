import React, { useState } from 'react';
import { Club, Player } from '../../types/game';
import { sound } from '../../utils/audio';
import { ArrowLeft, DollarSign, Coins, TrendingUp, TrendingDown, Building, Users, ShieldAlert, Award, Sliders, Check } from 'lucide-react';

interface FinancesViewProps {
  isArabic: boolean;
  myClub: Club;
  squad: Player[];
  onUpdateBudgets?: (transferBudget: number, wageBudgetWeekly: number) => void;
  onBack: () => void;
}

export const FinancesView: React.FC<FinancesViewProps> = ({
  isArabic,
  myClub,
  squad,
  onUpdateBudgets,
  onBack,
}) => {
  const weeklyWages = squad.reduce((acc, p) => acc + p.wage, 0);
  const staffList = Object.values(myClub.staff || {});
  const weeklyStaffCosts = staffList.reduce((acc, s) => acc + (s.salaryWeekly || 0), 0) + 2000;
  const matchdayGateRevenueEstimate = Math.round(
    myClub.stadiumCapacity * 0.8 * (myClub.ticketPrice || 25 + myClub.facilities.stands.level * 4)
  );
  const passiveStoreRevenue = myClub.facilities.clubStore.level * 4500;
  const maintenanceWeekly = 2500 + (myClub.facilities.stadium.level * 800);

  // Budget Allocation Slider state
  const totalFundingPool = myClub.budgetDollars + (myClub.wageBudgetWeekly * 10);
  const initialSlider = Math.round((myClub.budgetDollars / (totalFundingPool || 1)) * 100);
  const [transferPct, setTransferPct] = useState(Math.min(95, Math.max(5, initialSlider)));
  const [hasSavedSlider, setHasSavedSlider] = useState(false);

  const calculatedTransferBudget = Math.round((totalFundingPool * (transferPct / 100)));
  const calculatedWeeklyWageBudget = Math.round(((totalFundingPool * ((100 - transferPct) / 100)) / 10));

  const handleApplyBudgetSlider = () => {
    sound.playRewardChime();
    if (onUpdateBudgets) {
      onUpdateBudgets(calculatedTransferBudget, calculatedWeeklyWageBudget);
    }
    setHasSavedSlider(true);
    setTimeout(() => setHasSavedSlider(false), 2500);
  };

  const netWeekly = (passiveStoreRevenue + (matchdayGateRevenueEstimate / 2)) - (weeklyWages + weeklyStaffCosts + maintenanceWeekly);
  const healthGrade = netWeekly > 15000 ? 'A+' : netWeekly >= 0 ? 'A' : netWeekly > -20000 ? 'B' : 'C';

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 pb-20 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex items-center justify-between gap-4 mb-6">
        <button
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-bold transition cursor-pointer min-h-[44px]"
        >
          <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
          <span>{isArabic ? 'العودة للمقر' : 'Back to Dashboard'}</span>
        </button>

        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-500/30">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white">
              {isArabic ? 'التقرير المالي وإدارة الميزانيات' : 'Club Financial Statement & Budget Allocation'}
            </h2>
            <span className="text-xs text-slate-400">
              {isArabic ? 'ميزانية الانتقالات، سقف الرواتب، وتوزيع السيولة' : 'Transfer Budgets, Wage Bill Caps & Cash Flow'}
            </span>
          </div>
        </div>
      </div>

      {/* Dual Currency Distinction Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {/* Dollar Balance */}
        <div className="p-5 rounded-3xl bg-gradient-to-br from-emerald-950/60 to-slate-900 border border-emerald-500/40 shadow-xl flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">
              {isArabic ? 'ميزانية صفقات الانتقال ($)' : 'Transfer Budget (USD)'}
            </span>
            <h3 className="text-3xl sm:text-4xl font-black font-mono text-white mt-1">
              ${myClub.budgetDollars.toLocaleString()}
            </h3>
            <p className="text-xs text-slate-300 mt-2">
              {isArabic
                ? `سقف الرواتب الأسبوعي المعتمد: $${myClub.wageBudgetWeekly.toLocaleString()}`
                : `Approved Weekly Wage Cap: $${myClub.wageBudgetWeekly.toLocaleString()}`}
            </p>
          </div>
          <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-3xl shrink-0">
            💵
          </div>
        </div>

        {/* Koro Balance */}
        <div className="p-5 rounded-3xl bg-gradient-to-br from-purple-950/60 to-slate-900 border border-purple-500/40 shadow-xl flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-purple-400 uppercase tracking-wider block">
              {isArabic ? 'عملة الكورو (KORO) المخصصة للأكاديمية' : 'Academy & Wonderkids KORO Ledger'}
            </span>
            <h3 className="text-3xl sm:text-4xl font-black font-mono text-white mt-1">
              {myClub.balanceKoro.toLocaleString()} <span className="text-lg font-sans text-purple-300">KORO</span>
            </h3>
            <p className="text-xs text-slate-300 mt-2">
              {isArabic
                ? 'مخصصة لاكتشاف المواهب الناشئة وبرامج الكشافة في الأكاديمية.'
                : 'Allocated exclusively for elite scouting and youth prodigy contracts.'}
            </p>
          </div>
          <div className="w-14 h-14 rounded-2xl bg-purple-500/20 text-purple-400 flex items-center justify-center text-3xl shrink-0">
            🪙
          </div>
        </div>
      </div>

      {/* Transfer vs Wage Budget Allocation Slider */}
      <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 mb-6">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">
              {isArabic ? 'تعديل توزيع الميزانية (انتقالات مقابل رواتب)' : 'Budget Slider (Transfer vs Wage Allocation)'}
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {isArabic ? `التقييم المالي: ${healthGrade}` : `Financial Health: ${healthGrade}`}
          </span>
        </div>

        <p className="text-xs text-slate-400 mb-4">
          {isArabic
            ? 'يمكنك نقل جزء من ميزانية الانتقالات إلى ميزانية الرواتب الأسبوعية لإغراء النجوم الكبار، أو العكس لتوفير سيولة للصفقات.'
            : 'Shift funds between senior transfer acquisitions and weekly payroll headroom to match your recruitment goals.'}
        </p>

        <div className="space-y-4">
          <input
            type="range"
            min="10"
            max="90"
            value={transferPct}
            onChange={(e) => setTransferPct(Number(e.target.value))}
            className="w-full accent-emerald-500 cursor-pointer h-2 bg-slate-800 rounded-lg"
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
            <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750 flex items-center justify-between">
              <span className="text-slate-400 font-sans">{isArabic ? 'ميزانية الانتقالات المقترحة:' : 'Proposed Transfer Budget:'}</span>
              <span className="text-emerald-400 font-bold">${calculatedTransferBudget.toLocaleString()} ({transferPct}%)</span>
            </div>
            <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750 flex items-center justify-between">
              <span className="text-slate-400 font-sans">{isArabic ? 'سقف الرواتب الأسبوعي المقترح:' : 'Proposed Weekly Wage Cap:'}</span>
              <span className="text-teal-400 font-bold">${calculatedWeeklyWageBudget.toLocaleString()}/wk ({100 - transferPct}%)</span>
            </div>
          </div>

          <div className="flex justify-end pt-1">
            <button
              onClick={handleApplyBudgetSlider}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition cursor-pointer min-h-[44px] flex items-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>{hasSavedSlider ? (isArabic ? 'تم اعتماد التوزيع!' : 'Budgets Rebalanced!') : (isArabic ? 'اعتماد التوزيع المالي' : 'Confirm Budget Shift')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Revenue vs Expenditure Breakdowns */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Income Sources */}
        <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-800">
            <TrendingUp className="w-5 h-5 text-emerald-400" />
            <h4 className="text-sm font-bold text-white">
              {isArabic ? 'مصادر الإيرادات والتدفق المالي' : 'Income & Revenue Streams'}
            </h4>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div className="flex justify-between items-center p-3 rounded-xl bg-slate-800/40">
              <span className="text-slate-300 font-sans">{isArabic ? 'عوائد تذاكر المباراة البيتية' : 'Matchday Gate Receipts'}</span>
              <span className="text-emerald-400 font-bold">+${matchdayGateRevenueEstimate.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center p-3 rounded-xl bg-slate-800/40">
              <span className="text-slate-300 font-sans">{isArabic ? 'أرباح متجر النادي والرعايات الأسبوعية' : 'Store & Sponsor Commercial'}</span>
              <span className="text-emerald-400 font-bold">+${passiveStoreRevenue.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center p-3 rounded-xl bg-slate-800/40">
              <span className="text-slate-300 font-sans">{isArabic ? 'مكافأة الفوز بالمباراة الرسمية' : 'Match Victory Win Bonus'}</span>
              <span className="text-emerald-400 font-bold">+$15,000</span>
            </div>
            <div className="flex justify-between items-center p-3 rounded-xl bg-slate-800/40">
              <span className="text-slate-300 font-sans">{isArabic ? 'جوائز الصعود وبطل الدوري' : 'League Championship Prize Pot'}</span>
              <span className="text-amber-400 font-bold">+$500,000+</span>
            </div>
          </div>
        </div>

        {/* Expenses */}
        <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-800">
            <TrendingDown className="w-5 h-5 text-rose-400" />
            <h4 className="text-sm font-bold text-white">
              {isArabic ? 'المصروفات والالتزامات الأسبوعية' : 'Operating Expenses & Payroll (Weekly)'}
            </h4>
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div className="flex justify-between items-center p-3 rounded-xl bg-slate-800/40">
              <span className="text-slate-300 font-sans">{isArabic ? 'إجمالي رواتب قائمة اللاعبين' : 'First Team Squad Payroll'}</span>
              <span className="text-rose-400 font-bold">-${weeklyWages.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center p-3 rounded-xl bg-slate-800/40">
              <span className="text-slate-300 font-sans">{isArabic ? 'رواتب الكادر التدريبي والطبي والكشافين' : 'Coaching, Physio & Scout Payroll'}</span>
              <span className="text-rose-400 font-bold">-${weeklyStaffCosts.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center p-3 rounded-xl bg-slate-800/40">
              <span className="text-slate-300 font-sans">{isArabic ? 'صيانة منشآت الملعب والأرضية العشبية' : 'Stadium Grounds & Turf Upkeep'}</span>
              <span className="text-rose-400 font-bold">-${maintenanceWeekly.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center p-3 rounded-xl bg-slate-800/40">
              <span className="text-slate-300 font-sans">{isArabic ? 'صافي التدفق الأسبوعي التقديري' : 'Estimated Net Operating Flow'}</span>
              <span className={`font-bold ${netWeekly >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {netWeekly >= 0 ? `+$${netWeekly.toLocaleString()}` : `-$${Math.abs(netWeekly).toLocaleString()}`}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
