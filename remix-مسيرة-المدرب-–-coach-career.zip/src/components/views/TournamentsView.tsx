import React, { useState } from 'react';
import { Club, CupMatch, TopScorerEntry } from '../../types/game';
import { sound } from '../../utils/audio';
import { ArrowLeft, Trophy, Star, Shield, Award, Users, Flame, ChevronRight } from 'lucide-react';

interface TournamentsViewProps {
  isArabic: boolean;
  myClub: Club;
  cupMatches?: CupMatch[];
  topScorers?: TopScorerEntry[];
  onBack: () => void;
}

export const TournamentsView: React.FC<TournamentsViewProps> = ({
  isArabic,
  myClub,
  cupMatches = [],
  topScorers = [],
  onBack,
}) => {
  const [activeTab, setActiveTab] = useState<'pyramid' | 'cup' | 'europe' | 'leaders'>('pyramid');

  // Fallback demo cup fixtures if empty
  const defaultCupMatches: CupMatch[] = cupMatches.length > 0 ? cupMatches : [
    {
      id: 'cup_r16_1',
      roundNameEn: 'Quarter-Final',
      roundNameAr: 'ربع النهائي',
      homeClub: { id: myClub.id, nameEn: myClub.name, nameAr: myClub.arName, crest: myClub.crestIcon },
      awayClub: { id: 'club_leeds', nameEn: 'Leeds United', nameAr: 'ليدز يونايتد', crest: '⚔️' },
      isPlayed: false,
      isMyMatch: true,
    },
    {
      id: 'cup_r16_2',
      roundNameEn: 'Quarter-Final',
      roundNameAr: 'ربع النهائي',
      homeClub: { id: 'club_chelsea', nameEn: 'Chelsea', nameAr: 'تشيلسي', crest: '🦁' },
      awayClub: { id: 'club_arsenal', nameEn: 'Arsenal', nameAr: 'أرسنال', crest: '🔴' },
      isPlayed: true,
      homeScore: 1,
      awayScore: 2,
    },
    {
      id: 'cup_r16_3',
      roundNameEn: 'Quarter-Final',
      roundNameAr: 'ربع النهائي',
      homeClub: { id: 'club_manunited', nameEn: 'Manchester United', nameAr: 'مانشستر يونايتد', crest: '😈' },
      awayClub: { id: 'club_liverpool', nameEn: 'Liverpool', nameAr: 'ليفربول', crest: '🔴' },
      isPlayed: true,
      homeScore: 3,
      awayScore: 2,
    },
    {
      id: 'cup_r16_4',
      roundNameEn: 'Quarter-Final',
      roundNameAr: 'ربع النهائي',
      homeClub: { id: 'club_mancity', nameEn: 'Manchester City', nameAr: 'مانشستر سيتي', crest: '🦅' },
      awayClub: { id: 'club_tottenham', nameEn: 'Tottenham', nameAr: 'توتنهام', crest: '⚪' },
      isPlayed: true,
      homeScore: 4,
      awayScore: 1,
    },
  ];

  const defaultTopScorers: TopScorerEntry[] = topScorers.length > 0 ? topScorers : [
    { playerId: 'p1', nameEn: 'Marcus Armstrong', nameAr: 'ماركوس أرمسترونغ', clubNameEn: myClub.name, clubNameAr: myClub.arName, goals: 14, assists: 6, matches: 18 },
    { playerId: 'p2', nameEn: 'Callum Davies', nameAr: 'كالوم ديفيز', clubNameEn: 'Oldham Athletic', clubNameAr: 'أولدهام أثلتيك', goals: 12, assists: 3, matches: 17 },
    { playerId: 'p3', nameEn: 'Liam Sterling', nameAr: 'ليام ستيرلينغ', clubNameEn: 'York City', clubNameAr: 'يورك سيتي', goals: 11, assists: 7, matches: 18 },
    { playerId: 'p4', nameEn: 'Harrison Cole', nameAr: 'هاريسون كول', clubNameEn: 'Rochdale AFC', clubNameAr: 'روتشديل إيه إف سي', goals: 9, assists: 5, matches: 16 },
    { playerId: 'p5', nameEn: 'Jack Reynolds', nameAr: 'جاك رينولدز', clubNameEn: 'Wrexham AFC', clubNameAr: 'ريكسهام إيه إف سي', goals: 8, assists: 8, matches: 15 },
  ];

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 pb-20 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex items-center justify-between gap-4 mb-6">
        <button
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-bold transition cursor-pointer min-h-[44px]"
        >
          <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
          <span>{isArabic ? 'العودة للمقر' : 'Back to Dashboard'}</span>
        </button>

        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-indigo-950 text-indigo-400 border border-indigo-500/30">
            <Trophy className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white">
              {isArabic ? 'البطولات الإنجليزية والمجد الأوروبي' : 'Competitions & European Glory'}
            </h2>
            <span className="text-xs text-slate-400">
              {isArabic ? 'الدوريات، الكؤوس، ودوري أبطال أوروبا' : 'Leagues, Cups, and European Trophies'}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-900/80 rounded-2xl border border-slate-800 mb-6 overflow-x-auto">
        <button
          onClick={() => {
            sound.playClick();
            setActiveTab('pyramid');
          }}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'pyramid' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>{isArabic ? 'الهرم الإنجليزي (5 درجات)' : 'English Pyramid'}</span>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setActiveTab('cup');
          }}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'cup' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Trophy className="w-4 h-4" />
          <span>{isArabic ? 'كأس إنجلترا الوطني' : 'National Cup'}</span>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setActiveTab('europe');
          }}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'europe' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Star className="w-4 h-4" />
          <span>{isArabic ? 'دوري أبطال أوروبا' : 'Champions League'}</span>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setActiveTab('leaders');
          }}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'leaders' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Flame className="w-4 h-4" />
          <span>{isArabic ? 'الهدافين وصناع اللعب' : 'Top Scorers'}</span>
        </button>
      </div>

      {/* Tab 1: English Pyramid */}
      {activeTab === 'pyramid' && (
        <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800">
          <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>{isArabic ? 'هرم الدوريات الإنجليزية (طريق الصعود والمجد)' : 'English Football Pyramid Ladder'}</span>
          </h3>
          <p className="text-xs text-slate-400 mb-5">
            {isArabic
              ? 'تصدر الدوري في كل موسم يضمن لك الصعود المباشر إلى الدرجة الأعلى، حتى بلوغ البريميرليغ والتأهل لكؤوس أوروبا.'
              : 'Finishing top 2 guarantees direct promotion upwards towards the Premier League and European qualification.'}
          </p>

          <div className="space-y-3">
            {[
              { tier: 1, nameEn: 'Premier League', nameAr: 'الدوري الإنجليزي الممتاز (بريميرليغ)', perkAr: 'المشاركة في دوري أبطال أوروبا والجوائز الكبرى ($120M+)', perkEn: 'UCL Qualification & $120M+ TV Rights', icon: '👑', prize: '$120,000,000' },
              { tier: 2, nameEn: 'Championship', nameAr: 'دوري الدرجة الثانية (التشامبيونشيب)', perkAr: 'صراع الصعود للأضواء وجوائز مالية ضخمة ($25M)', perkEn: 'High-stakes battle for Premier League spots', icon: '⚔️', prize: '$25,000,000' },
              { tier: 3, nameEn: 'League One', nameAr: 'دوري الدرجة الثالثة (ليغ ون)', perkAr: 'منافسة قوية وملاعب متوسطة السعة ($6M)', perkEn: 'Competitive tier with expanding stadiums', icon: '🛡️', prize: '$6,000,000' },
              { tier: 4, nameEn: 'League Two', nameAr: 'دوري الدرجة الرابعة (ليغ تو)', perkAr: 'بوابة الاحتراف الكامل وصيد المواهب ($2M)', perkEn: 'Fully professional status & scouting hubs', icon: '⚽', prize: '$2,000,000' },
              { tier: 5, nameEn: 'National League', nameAr: 'الدرجة الخامسة (الناشيونال ليغ - نقطة البداية)', perkAr: 'البداية الحقيقية والشغف الخالص للجماهير ($600K)', perkEn: 'The true grassroots starting tier', icon: '🌱', prize: '$600,000' },
            ].map(lvl => {
              const isCurrentTier = myClub.tier === lvl.tier;
              return (
                <div
                  key={lvl.tier}
                  className={`p-4 rounded-2xl border transition flex items-center justify-between ${
                    isCurrentTier
                      ? 'bg-emerald-950/60 border-emerald-400 text-white font-bold ring-1 ring-emerald-400'
                      : 'bg-slate-850/50 border-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-3.5">
                    <span className="text-2xl">{lvl.icon}</span>
                    <div>
                      <h4 className="text-xs sm:text-sm font-bold">
                        {isArabic ? lvl.nameAr : lvl.nameEn}
                      </h4>
                      <span className="text-[11px] text-slate-400 block mt-0.5">
                        {isArabic ? lvl.perkAr : lvl.perkEn}
                      </span>
                    </div>
                  </div>

                  <div className="text-right rtl:text-left">
                    {isCurrentTier ? (
                      <span className="px-2.5 py-1 rounded-full bg-emerald-500 text-slate-950 font-black text-[10px]">
                        {isArabic ? 'درجتك الحالية' : 'CURRENT TIER'}
                      </span>
                    ) : (
                      <span className="text-xs font-mono text-slate-400">Tier {lvl.tier}</span>
                    )}
                    <span className="text-[10px] text-emerald-400 font-mono block mt-1">
                      {lvl.prize}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 2: National Cup */}
      {activeTab === 'cup' && (
        <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Trophy className="w-4 h-4 text-amber-400" />
                <span>{isArabic ? 'كأس إنجلترا الوطني (خروج المغلوب)' : 'The National FA Cup Bracket'}</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                {isArabic
                  ? 'مباريات خروج مغلوب تجمع كافة أندية إنجلترا من الدرجة الخامسة حتى الممتاز.'
                  : 'Knockout tournament pitting all English tiers from grassroots to Premier League giants.'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
            {defaultCupMatches.map(match => (
              <div
                key={match.id}
                className={`p-3.5 rounded-2xl border transition ${
                  match.isMyMatch
                    ? 'bg-amber-950/40 border-amber-500/50 ring-1 ring-amber-500/40'
                    : 'bg-slate-850/40 border-slate-800'
                }`}
              >
                <div className="flex items-center justify-between text-[11px] text-slate-400 pb-2 border-b border-slate-800 mb-2 font-mono">
                  <span>{isArabic ? match.roundNameAr : match.roundNameEn}</span>
                  {match.isMyMatch && (
                    <span className="text-amber-400 font-bold font-sans">
                      {isArabic ? 'مباراة فريقك القادمة!' : 'YOUR CUP FIXTURE'}
                    </span>
                  )}
                </div>

                <div className="space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 font-bold text-white">
                      <span>{match.homeClub.crest}</span>
                      <span>{isArabic ? match.homeClub.nameAr : match.homeClub.nameEn}</span>
                    </span>
                    <span className="font-mono font-bold text-slate-200">
                      {match.isPlayed ? match.homeScore : '-'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 font-bold text-white">
                      <span>{match.awayClub.crest}</span>
                      <span>{isArabic ? match.awayClub.nameAr : match.awayClub.nameEn}</span>
                    </span>
                    <span className="font-mono font-bold text-slate-200">
                      {match.isPlayed ? match.awayScore : '-'}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: European Glory */}
      {activeTab === 'europe' && (
        <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Star className="w-4 h-4 text-cyan-400" />
                <span>{isArabic ? 'دوري أبطال أوروبا (قمة المجد الكروي)' : 'UEFA Champions League'}</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                {isArabic
                  ? 'يتأهل أصحاب المراكز الأربعة الأولى في الدوري الإنجليزي الممتاز لمواجهة عمالقة القارة الأوروبية.'
                  : 'Top 4 finishers in the Premier League qualify to compete against Europe’s elite superclubs.'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {[
              { name: 'Real Madrid', ar: 'ريال مدريد', crest: '👑', nation: 'Spain', ucl: 15 },
              { name: 'Bayern Munich', ar: 'بايرن ميونخ', crest: '🔴', nation: 'Germany', ucl: 6 },
              { name: 'FC Barcelona', ar: 'برشلونة', crest: '🔵🔴', nation: 'Spain', ucl: 5 },
              { name: 'Paris Saint-Germain', ar: 'باريس سان جيرمان', crest: '🗼', nation: 'France', ucl: 0 },
              { name: 'Inter Milan', ar: 'إنتر ميلان', crest: '🐍', nation: 'Italy', ucl: 3 },
              { name: 'Manchester City', ar: 'مانشستر سيتي', crest: '🦅', nation: 'England', ucl: 1 },
            ].map(team => (
              <div key={team.name} className="p-3.5 rounded-2xl bg-slate-850/40 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span className="text-2xl">{team.crest}</span>
                  <div>
                    <h4 className="text-xs font-bold text-white">{isArabic ? team.ar : team.name}</h4>
                    <span className="text-[10px] text-slate-400">{team.nation}</span>
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold text-cyan-400">
                  {team.ucl} UCL Titles
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Top Scorers & Assists */}
      {activeTab === 'leaders' && (
        <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Flame className="w-4 h-4 text-amber-400" />
            <span>{isArabic ? 'الحذاء الذهبي وصناع الأهداف (إحصائيات اللاعبين)' : 'Golden Boot & Playmaker Leaderboards'}</span>
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left rtl:text-right">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-semibold">
                  <th className="py-2.5 px-3">#</th>
                  <th className="py-2.5 px-3">{isArabic ? 'اللاعب' : 'Player'}</th>
                  <th className="py-2.5 px-3">{isArabic ? 'النادي' : 'Club'}</th>
                  <th className="py-2.5 px-3 text-center">{isArabic ? 'المباريات' : 'Apps'}</th>
                  <th className="py-2.5 px-3 text-center">{isArabic ? 'الأهداف' : 'Goals'}</th>
                  <th className="py-2.5 px-3 text-center">{isArabic ? 'الصناعة' : 'Assists'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {defaultTopScorers.map((s, idx) => (
                  <tr key={s.playerId} className="hover:bg-slate-800/30 transition">
                    <td className="py-2.5 px-3 font-bold text-amber-400">{idx + 1}</td>
                    <td className="py-2.5 px-3 font-sans font-bold text-white">
                      {isArabic ? s.nameAr : s.nameEn}
                    </td>
                    <td className="py-2.5 px-3 font-sans text-slate-300">
                      {isArabic ? s.clubNameAr : s.clubNameEn}
                    </td>
                    <td className="py-2.5 px-3 text-center text-slate-400">{s.matches}</td>
                    <td className="py-2.5 px-3 text-center font-bold text-emerald-400">{s.goals}</td>
                    <td className="py-2.5 px-3 text-center font-bold text-cyan-400">{s.assists}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
