import React, { useState } from 'react';
import { Formation, PlayStyle, Player, Tactics, PassingStyle, DefensiveLine, PressingIntensity, Tempo } from '../../types/game';
import { sound } from '../../utils/audio';
import { ArrowLeft, Layers, Shield, Award, Activity, Check, RefreshCw, Sliders, Target, Crosshair } from 'lucide-react';

interface TacticsViewProps {
  isArabic: boolean;
  squad: Player[];
  tactics: Tactics;
  onUpdateTactics: (newTactics: Tactics) => void;
  onBack: () => void;
}

const FORMATIONS: { id: Formation; label: string }[] = [
  { id: '4-3-3', label: '4-3-3 Attacking' },
  { id: '4-4-2', label: '4-4-2 Classic' },
  { id: '4-2-3-1', label: '4-2-3-1 Modern' },
  { id: '3-5-2', label: '3-5-2 Wingbacks' },
  { id: '5-3-2', label: '5-3-2 Low Block' },
  { id: '4-1-4-1', label: '4-1-4-1 Controlled' },
  { id: '3-4-3', label: '3-4-3 Total Attack' },
];

const PLAY_STYLES: { id: PlayStyle; nameEn: string; nameAr: string; descEn: string; descAr: string }[] = [
  { id: 'balanced', nameEn: 'Balanced', nameAr: 'تكتيك متوازن', descEn: 'Steady game tempo and structured coverage', descAr: 'توازن محكم بين الارتداد والمساندة الهجومية' },
  { id: 'attacking', nameEn: 'Attacking', nameAr: 'هجوم شامل', descEn: 'Heavy numbers pushed forward into opposition box', descAr: 'كثافة هجومية عالية في منطقة جزاء الخصم' },
  { id: 'high_press', nameEn: 'High Press', nameAr: 'ضغط عالي شرس', descEn: 'Suffocate opponent in their own half (higher fatigue)', descAr: 'خنق الخصم في مناطقه مع استهلاك بدني أعلى' },
  { id: 'counter', nameEn: 'Counter-Attack', nameAr: 'هجمات مرتدة سريعة', descEn: 'Absorb pressure and break rapidly through wingers', descAr: 'امتصاص الضغط والانطلاق الخاطف عبر الأجنحة' },
  { id: 'defensive', nameEn: 'Park the Bus (Defensive)', nameAr: 'دفاع المنطقة والتحصين', descEn: 'Double-decker defense to protect the clean sheet', descAr: 'تكتل دفاعي صارم وإغلاق تام لكافة المساحات' },
];

export const TacticsView: React.FC<TacticsViewProps> = ({
  isArabic,
  squad,
  tactics,
  onUpdateTactics,
  onBack,
}) => {
  const [currentFormation, setCurrentFormation] = useState<Formation>(tactics.formation);
  const [currentStyle, setCurrentStyle] = useState<PlayStyle>(tactics.playStyle);
  const [passingStyle, setPassingStyle] = useState<PassingStyle>(tactics.passingStyle || 'short');
  const [defensiveLine, setDefensiveLine] = useState<DefensiveLine>(tactics.defensiveLine || 'standard');
  const [pressingIntensity, setPressingIntensity] = useState<PressingIntensity>(tactics.pressingIntensity || 'balanced');
  const [tempo, setTempo] = useState<Tempo>(tactics.tempo || 'normal');
  
  const [startingXI, setStartingXI] = useState<string[]>(tactics.startingXI);
  const [selectedPlayerToSwap, setSelectedPlayerToSwap] = useState<string | null>(null);
  const [captainId, setCaptainId] = useState<string>(tactics.captainId || squad[0]?.id);
  const [penaltyTakerId, setPenaltyTakerId] = useState<string>(tactics.penaltyTakerId || squad[0]?.id);

  // Group squad into starting XI and bench
  const starters = startingXI.map(id => squad.find(p => p.id === id)).filter(Boolean) as Player[];
  const benchPlayers = squad.filter(p => !startingXI.includes(p.id));

  const saveUpdatedTactics = (overrides: Partial<Tactics> = {}) => {
    const updated: Tactics = {
      formation: currentFormation,
      playStyle: currentStyle,
      passingStyle,
      defensiveLine,
      pressingIntensity,
      tempo,
      startingXI,
      bench: squad.filter(p => !startingXI.includes(p.id)).map(p => p.id).slice(0, 7),
      captainId,
      penaltyTakerId,
      ...overrides,
    };
    onUpdateTactics(updated);
  };

  const handleSwap = (clickedId: string) => {
    sound.playClick();
    if (!selectedPlayerToSwap) {
      setSelectedPlayerToSwap(clickedId);
    } else {
      if (selectedPlayerToSwap === clickedId) {
        setSelectedPlayerToSwap(null);
        return;
      }

      // Swap between startingXI or bench
      const newXI = [...startingXI];
      const isAInXI = newXI.includes(selectedPlayerToSwap);
      const isBInXI = newXI.includes(clickedId);

      if (isAInXI && isBInXI) {
        const idxA = newXI.indexOf(selectedPlayerToSwap);
        const idxB = newXI.indexOf(clickedId);
        newXI[idxA] = clickedId;
        newXI[idxB] = selectedPlayerToSwap;
      } else if (isAInXI && !isBInXI) {
        const idxA = newXI.indexOf(selectedPlayerToSwap);
        newXI[idxA] = clickedId;
      } else if (!isAInXI && isBInXI) {
        const idxB = newXI.indexOf(clickedId);
        newXI[idxB] = selectedPlayerToSwap;
      }

      setStartingXI(newXI);
      setSelectedPlayerToSwap(null);
      saveUpdatedTactics({ startingXI: newXI });
    }
  };

  const handleFormationChange = (form: Formation) => {
    sound.playClick();
    setCurrentFormation(form);
    saveUpdatedTactics({ formation: form });
  };

  const handleStyleChange = (style: PlayStyle) => {
    sound.playClick();
    setCurrentStyle(style);
    saveUpdatedTactics({ playStyle: style });
  };

  const handleCaptainChange = (id: string) => {
    sound.playRewardChime();
    setCaptainId(id);
    saveUpdatedTactics({ captainId: id });
  };

  const handlePenaltyTakerChange = (id: string) => {
    sound.playRewardChime();
    setPenaltyTakerId(id);
    saveUpdatedTactics({ penaltyTakerId: id });
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 pb-20 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex items-center justify-between gap-4 mb-6">
        <button
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-bold transition cursor-pointer min-h-[44px]"
        >
          <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
          <span>{isArabic ? 'العودة للمقر' : 'Back to Dashboard'}</span>
        </button>

        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-teal-950 text-teal-400 border border-teal-500/30">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white">
              {isArabic ? 'مختبر التكتيك والخطط الكروية' : 'Tactics & Formation Laboratory'}
            </h2>
            <span className="text-xs text-slate-400">
              {isArabic ? 'تشكيلات متعددة، أسلوب لعب، وتعليمات تفصيلية' : 'Formations, Playing Styles & Tactical Directives'}
            </span>
          </div>
        </div>
      </div>

      {/* Formation & PlayStyle Selectors */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {/* Formations */}
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
          <label className="block text-xs font-bold text-slate-300 mb-2">
            {isArabic ? 'الخطة التكتيكية' : 'Formation Setup'}
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {FORMATIONS.map(f => (
              <button
                key={f.id}
                onClick={() => handleFormationChange(f.id)}
                className={`py-2 px-2.5 rounded-xl text-xs font-mono font-bold transition cursor-pointer min-h-[42px] ${
                  currentFormation === f.id
                    ? 'bg-teal-600 text-white shadow-md'
                    : 'bg-slate-800/80 text-slate-400 hover:text-white'
                }`}
              >
                {f.id}
              </button>
            ))}
          </div>
        </div>

        {/* Playstyles */}
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
          <label className="block text-xs font-bold text-slate-300 mb-2">
            {isArabic ? 'فلسفة وعقلية الفريق' : 'Team Mentality & Style'}
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {PLAY_STYLES.map(s => (
              <button
                key={s.id}
                onClick={() => handleStyleChange(s.id)}
                className={`py-2 px-2.5 rounded-xl text-xs font-bold transition cursor-pointer min-h-[42px] ${
                  currentStyle === s.id
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'bg-slate-800/80 text-slate-400 hover:text-white'
                }`}
              >
                {isArabic ? s.nameAr : s.nameEn}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Detailed Tactical Instructions Panel */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 mb-6">
        <h3 className="text-xs font-bold text-slate-300 mb-3 flex items-center gap-1.5">
          <Sliders className="w-4 h-4 text-emerald-400" />
          <span>{isArabic ? 'التعليمات التكتيكية التفصيلية (Tactical Instructions)' : 'Detailed Match Directives'}</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Passing Style */}
          <div className="p-3 rounded-xl bg-slate-850/60 border border-slate-800">
            <span className="text-[11px] font-semibold text-slate-400 block mb-1.5">
              {isArabic ? 'أسلوب التمرير:' : 'Passing Style:'}
            </span>
            <div className="grid grid-cols-3 gap-1 text-[11px] font-bold">
              {(['short', 'mixed', 'direct'] as const).map(style => (
                <button
                  key={style}
                  onClick={() => {
                    setPassingStyle(style);
                    saveUpdatedTactics({ passingStyle: style });
                  }}
                  className={`py-1 rounded-lg transition ${
                    passingStyle === style ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {style === 'short' ? (isArabic ? 'قصير' : 'Short') : style === 'mixed' ? (isArabic ? 'مختلط' : 'Mixed') : (isArabic ? 'مباشر' : 'Direct')}
                </button>
              ))}
            </div>
          </div>

          {/* Defensive Line */}
          <div className="p-3 rounded-xl bg-slate-850/60 border border-slate-800">
            <span className="text-[11px] font-semibold text-slate-400 block mb-1.5">
              {isArabic ? 'الخط الدفاعي:' : 'Defensive Line:'}
            </span>
            <div className="grid grid-cols-3 gap-1 text-[11px] font-bold">
              {(['deep', 'standard', 'high'] as const).map(line => (
                <button
                  key={line}
                  onClick={() => {
                    setDefensiveLine(line);
                    saveUpdatedTactics({ defensiveLine: line });
                  }}
                  className={`py-1 rounded-lg transition ${
                    defensiveLine === line ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {line === 'deep' ? (isArabic ? 'متراجع' : 'Deep') : line === 'standard' ? (isArabic ? 'متوسط' : 'Medium') : (isArabic ? 'متقدم' : 'High')}
                </button>
              ))}
            </div>
          </div>

          {/* Pressing Intensity */}
          <div className="p-3 rounded-xl bg-slate-850/60 border border-slate-800">
            <span className="text-[11px] font-semibold text-slate-400 block mb-1.5">
              {isArabic ? 'شدة الضغط:' : 'Pressing Intensity:'}
            </span>
            <div className="grid grid-cols-3 gap-1 text-[11px] font-bold">
              {(['light', 'balanced', 'relentless'] as const).map(press => (
                <button
                  key={press}
                  onClick={() => {
                    setPressingIntensity(press);
                    saveUpdatedTactics({ pressingIntensity: press });
                  }}
                  className={`py-1 rounded-lg transition ${
                    pressingIntensity === press ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {press === 'light' ? (isArabic ? 'هادئ' : 'Light') : press === 'balanced' ? (isArabic ? 'متوازن' : 'Balanced') : (isArabic ? 'شرس' : 'Relentless')}
                </button>
              ))}
            </div>
          </div>

          {/* Tempo */}
          <div className="p-3 rounded-xl bg-slate-850/60 border border-slate-800">
            <span className="text-[11px] font-semibold text-slate-400 block mb-1.5">
              {isArabic ? 'إيقاع اللعب (الرتم):' : 'Tempo:'}
            </span>
            <div className="grid grid-cols-3 gap-1 text-[11px] font-bold">
              {(['patient', 'normal', 'fast'] as const).map(t => (
                <button
                  key={t}
                  onClick={() => {
                    setTempo(t);
                    saveUpdatedTactics({ tempo: t });
                  }}
                  className={`py-1 rounded-lg transition ${
                    tempo === t ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {t === 'patient' ? (isArabic ? 'صبور' : 'Patient') : t === 'normal' ? (isArabic ? 'طبيعي' : 'Normal') : (isArabic ? 'سريع' : 'Fast')}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Pitch & Bench Split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Visual Football Pitch (Starting XI) */}
        <div className="lg:col-span-2 relative min-h-[520px] rounded-3xl pitch-pattern border-4 border-slate-800 p-4 sm:p-6 shadow-2xl flex flex-col justify-between overflow-hidden">
          {/* Pitch Markings */}
          <div className="absolute inset-x-8 top-1/2 -translate-y-1/2 h-0.5 bg-white/15 pointer-events-none" />
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 rounded-full border-2 border-white/15 pointer-events-none" />
          <div className="absolute left-1/2 top-0 -translate-x-1/2 w-48 h-20 border-b-2 border-x-2 border-white/15 pointer-events-none" />
          <div className="absolute left-1/2 bottom-0 -translate-x-1/2 w-48 h-20 border-t-2 border-x-2 border-white/15 pointer-events-none" />

          {/* Swap Notice Banner */}
          {selectedPlayerToSwap && (
            <div className="absolute top-3 left-1/2 -translate-x-1/2 px-4 py-1.5 rounded-full bg-amber-500 text-slate-950 font-black text-xs shadow-lg animate-pulse z-30">
              {isArabic ? 'انقر على لاعب آخر لإتمام التبديل' : 'Tap another player to complete swap'}
            </div>
          )}

          {/* Starters Grid mapped across pitch */}
          <div className="relative z-10 grid grid-cols-3 sm:grid-cols-4 gap-3 my-auto">
            {starters.map(player => {
              const isSelected = selectedPlayerToSwap === player.id;
              const isCaptain = captainId === player.id;
              const isPenaltyTaker = penaltyTakerId === player.id;

              return (
                <div
                  key={player.id}
                  onClick={() => handleSwap(player.id)}
                  className={`p-2.5 rounded-2xl backdrop-blur-md border transition cursor-pointer flex flex-col items-center text-center shadow-lg group ${
                    isSelected
                      ? 'bg-amber-500/80 border-amber-300 text-slate-950 scale-105 ring-2 ring-amber-300'
                      : 'bg-slate-950/75 border-white/15 text-white hover:border-emerald-400'
                  }`}
                >
                  <div className="relative mb-1">
                    <div className="w-10 h-10 rounded-full bg-slate-800 border border-white/30 flex items-center justify-center font-bold text-xs text-emerald-400">
                      {player.position}
                    </div>
                    {isCaptain && (
                      <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-400 text-slate-950 font-black text-[9px] flex items-center justify-center border border-black shadow">
                        C
                      </div>
                    )}
                    {isPenaltyTaker && (
                      <div className="absolute -top-1 -left-1 w-4 h-4 rounded-full bg-emerald-400 text-slate-950 font-black text-[9px] flex items-center justify-center border border-black shadow">
                        P
                      </div>
                    )}
                  </div>

                  <span className="text-xs font-bold truncate max-w-[100px]">
                    {isArabic ? player.arName : player.name}
                  </span>
                  
                  <div className="flex items-center gap-1.5 text-[10px] font-mono mt-0.5">
                    <span className="text-amber-400 font-bold">{player.ovr}</span>
                    <span className="text-slate-400">·</span>
                    <span className="text-emerald-400">{player.fitness}%</span>
                  </div>

                  {/* Captain & Penalty Taker Assign Buttons */}
                  <div className="mt-1 flex items-center gap-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCaptainChange(player.id);
                      }}
                      className="text-[9px] px-1 py-0.5 rounded bg-slate-800/80 text-slate-400 hover:text-amber-300 font-semibold"
                    >
                      {isCaptain ? 'Captain' : '(C)'}
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePenaltyTakerChange(player.id);
                      }}
                      className="text-[9px] px-1 py-0.5 rounded bg-slate-800/80 text-slate-400 hover:text-emerald-300 font-semibold"
                    >
                      {isPenaltyTaker ? 'Penalty' : '(P)'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bench & Substitutes Panel */}
        <div className="p-4 sm:p-5 rounded-3xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white mb-1 flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-emerald-400" />
              <span>{isArabic ? 'دكة البدلاء والاحتياط' : 'Substitutes & Reserves'}</span>
            </h3>
            <p className="text-[11px] text-slate-400 mb-4">
              {isArabic ? 'انقر على أي بديل لتبديله مع لاعب في الملعب' : 'Tap any substitute to swap into starting XI'}
            </p>

            <div className="space-y-2 max-h-[460px] overflow-y-auto pr-1">
              {benchPlayers.map(player => {
                const isSelected = selectedPlayerToSwap === player.id;
                return (
                  <div
                    key={player.id}
                    onClick={() => handleSwap(player.id)}
                    className={`p-3 rounded-2xl border transition cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-amber-500 text-slate-950 border-amber-300 font-bold'
                        : 'bg-slate-850/60 border-slate-700/60 hover:bg-slate-800 text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-slate-800 text-xs font-bold text-emerald-400 flex items-center justify-center">
                        {player.position}
                      </div>
                      <div>
                        <span className="text-xs font-bold block truncate max-w-[120px]">
                          {isArabic ? player.arName : player.name}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {player.age} {isArabic ? 'سنة' : 'yrs'} · {player.fitness}% {isArabic ? 'لياقة' : 'fit'}
                        </span>
                      </div>
                    </div>

                    <div className="font-mono text-xs font-bold text-amber-400">
                      {player.ovr} OVR
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
