import React from 'react';
import { Club, StaffMember, StaffRole } from '../types/game';
import { sound } from '../utils/audio';
import { X, Award, Users, HeartPulse, Compass, ChevronUp, DollarSign, CheckCircle, Shield } from 'lucide-react';

interface StaffModalProps {
  isOpen: boolean;
  isArabic: boolean;
  myClub: Club;
  onUpgradeStaff: (role: StaffRole, cost: number) => void;
  onClose: () => void;
}

export const StaffModal: React.FC<StaffModalProps> = ({
  isOpen,
  isArabic,
  myClub,
  onUpgradeStaff,
  onClose,
}) => {
  if (!isOpen) return null;

  const staffList = Object.values(myClub.staff || {}) as StaffMember[];
  const totalWeeklyStaffWages = staffList.reduce((acc, s) => acc + (s.salaryWeekly || 0), 0);

  const getRoleIcon = (role: StaffRole) => {
    switch (role) {
      case 'headCoach':
        return <Award className="w-5 h-5 text-amber-400" />;
      case 'chiefScout':
        return <Compass className="w-5 h-5 text-cyan-400" />;
      case 'headPhysio':
        return <HeartPulse className="w-5 h-5 text-rose-400" />;
    }
  };

  const handleUpgrade = (staff: StaffMember) => {
    if (staff.level >= 5) return;
    if (myClub.budgetDollars < staff.upgradeCost) {
      return;
    }
    sound.playUpgrade();
    onUpgradeStaff(staff.id, staff.upgradeCost);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-[#0b1322] border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-400">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">
                {isArabic ? 'إدارة الطاقم الفني والطبي والكشافة' : 'Club Staff & Backroom Roster'}
              </h2>
              <span className="text-xs text-slate-400">
                {isArabic
                  ? `إجمالي رواتب الطاقم: $${totalWeeklyStaffWages.toLocaleString()} أسبوعياً`
                  : `Total staff payroll: $${totalWeeklyStaffWages.toLocaleString()} / week`}
              </span>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4">
          <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/40 p-3.5 rounded-2xl border border-slate-800/80">
            {isArabic
              ? 'الاستثمار في الكادر الفني والطبي يمنح فريقك أفضلية حاسمة في المباريات؛ فالمدرب يسرع تطور اللاعبين، والكشاف يكشف الجواهر النادرة، والطبيب يحمي نجومك من شبح الغيابات الطويلة.'
              : 'Investing in elite backroom staff provides key tactical advantages: coaches accelerate growth, scouts discover cheap wonderkids, and physios slash injury lay-offs.'}
          </p>

          <div className="grid grid-cols-1 gap-4">
            {staffList.map((staff) => {
              const isMax = staff.level >= 5;
              const canAfford = myClub.budgetDollars >= staff.upgradeCost;

              return (
                <div
                  key={staff.id}
                  className="p-4 sm:p-5 rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-slate-700 transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                >
                  <div className="flex items-start gap-3.5">
                    <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/60 shrink-0">
                      {getRoleIcon(staff.id)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-white">
                          {isArabic ? staff.nameAr : staff.nameEn}
                        </h4>
                        <span className="text-[11px] font-mono px-2 py-0.5 rounded-md bg-slate-800 text-teal-400 font-bold border border-slate-700">
                          {isArabic ? `المستوى ${staff.level} / 5` : `Level ${staff.level} / 5`}
                        </span>
                      </div>

                      <p className="text-xs text-slate-400 mt-1">
                        {isArabic ? staff.descriptionAr : staff.descriptionEn}
                      </p>

                      <div className="mt-2 flex items-center gap-2 text-xs font-medium text-emerald-400">
                        <CheckCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>{isArabic ? staff.perkAr : staff.perkEn}</span>
                      </div>

                      <div className="mt-1 text-[11px] text-slate-500 font-mono">
                        {isArabic
                          ? `الراتب الأسبوعي: $${staff.salaryWeekly.toLocaleString()}`
                          : `Weekly Wage: $${staff.salaryWeekly.toLocaleString()}`}
                      </div>
                    </div>
                  </div>

                  {/* Action / Upgrade button */}
                  <div className="w-full sm:w-auto shrink-0 flex items-center justify-end">
                    {isMax ? (
                      <div className="px-4 py-2 rounded-xl bg-slate-800 text-slate-400 text-xs font-bold border border-slate-700 text-center">
                        {isArabic ? 'الحد الأقصى (مكتمل)' : 'Max Level'}
                      </div>
                    ) : (
                      <button
                        onClick={() => handleUpgrade(staff)}
                        disabled={!canAfford}
                        className={`w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer min-h-[44px] ${
                          canAfford
                            ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-lg shadow-emerald-900/30'
                            : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                        }`}
                      >
                        <ChevronUp className="w-4 h-4" />
                        <span>
                          {isArabic ? 'ترقية وتطوير' : 'Upgrade Staff'}
                        </span>
                        <span className="font-mono opacity-90">
                          (${staff.upgradeCost.toLocaleString()})
                        </span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-900/60 flex items-center justify-between text-xs text-slate-400 shrink-0">
          <span>
            {isArabic
              ? `رصيد النادي المتاح: $${myClub.budgetDollars.toLocaleString()}`
              : `Available Club Budget: $${myClub.budgetDollars.toLocaleString()}`}
          </span>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold transition cursor-pointer min-h-[40px]"
          >
            {isArabic ? 'إغلاق' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
